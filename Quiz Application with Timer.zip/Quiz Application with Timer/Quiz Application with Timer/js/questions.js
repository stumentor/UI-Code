// creating an array and passing the number, questions, options, and answers
let questions = {
	"III": [{
			"numb": 1,
			"question": "What does HTML stand for?",
			"answer": "Hyper Text Markup Language",
			"options": [
				"Hyper Text Preprocessor",
				"Hyper Text Markup Language",
				"Hyper Text Multiple Language",
				"Hyper Tool Multi Language"
			]
		},
		{
			"numb": 2,
			"question": "What does CSS stand for?",
			"answer": "Cascading Style Sheet",
			"options": [
				"Common Style Sheet",
				"Colorful Style Sheet",
				"Computer Style Sheet",
				"Cascading Style Sheet"
			]
		}
	],

	"IV": [{
			"numb": 1,
			"question": "What does CSS stand for?",
			"answer": "Cascading Style Sheet",
			"options": [
				"Common Style Sheet",
				"Colorful Style Sheet",
				"Computer Style Sheet",
				"Cascading Style Sheet"
			]
		},
		{
			"numb": 2,
			"question": "What does CSS stand for?",
			"answer": "Cascading Style Sheet",
			"options": [
				"Common Style Sheet",
				"Colorful Style Sheet",
				"Computer Style Sheet",
				"Cascading Style Sheet"
			]
		}
	]
};